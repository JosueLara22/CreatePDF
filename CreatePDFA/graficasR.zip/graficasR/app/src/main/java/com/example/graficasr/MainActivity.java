package com.example.graficasr;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.Chart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.LegendEntry;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.DataSet;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.formatter.PercentFormatter;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private PieChart mPieChart;
    private BarChart mBarChart;
    private String[] mMonths =new String []{"E","F","Mr","A","My","Jn","Jl","A","S","O","N","D"};
    private float[] msale =new float[]{12,10,(float) 9.1,3,6,12,5,(float)10.68,11,15,14, (float) 11.8};
    private int[] mColors =new int[]{Color.GREEN,Color.GRAY,Color.GREEN,Color.GRAY,Color.GREEN,
            Color.GRAY,Color.GREEN,Color.GRAY,Color.GREEN,Color.GRAY,Color.GREEN,Color.GRAY};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mBarChart =(BarChart)findViewById(R.id.barChart);
        mPieChart =(PieChart) findViewById(R.id.pieChart);
        //createdCharts();
        GraphingUtils.setBarGraphic(mBarChart, msale, mMonths, Color.GREEN, "Series",
        Color.BLACK, Color.WHITE, 3000, "LABEL");
    }
    private Chart getSameChart(Chart chart,String description,int textColor,
                               int background,int animateY){
        chart.getDescription().setText(description);
        chart.getDescription().setTextSize(15);
        chart.setBackgroundColor(background);
        chart.animateY(animateY);
        legend(chart);
        return chart;
    }
    private void legend(Chart chart){
        Legend legend=chart.getLegend();
        legend.setForm(Legend.LegendForm.CIRCLE);
        legend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.CENTER);

        ArrayList<LegendEntry>entries=new ArrayList<>();
        for(int i = 0; i< mMonths.length; i++){
            LegendEntry entry=new LegendEntry();
            entry.formColor= mColors[i];
            entry.label= mMonths[i];
        }
        legend.setCustom(entries);
    }
    private ArrayList<BarEntry>getBarEntries(){
        ArrayList<BarEntry>entries=new ArrayList<>();
        for(int i = 0; i< mMonths.length; i++)
            entries.add(new BarEntry(i, msale[i]));
        return entries;
    }
    private ArrayList<PieEntry>getPierEntries(){
        ArrayList<PieEntry>entries=new ArrayList<>();
        for(int i = 0; i< mMonths.length; i++)
            entries.add(new PieEntry(msale[i]));
        return entries;
    }
    private void axisX(XAxis axis){
        axis.setGranularityEnabled(true);
        axis.setPosition(XAxis.XAxisPosition.BOTTOM);
        axis.setValueFormatter(new IndexAxisValueFormatter(mMonths));
    }
    private void axisLeft(YAxis axis){
        axis.setSpaceTop(20);
        axis.setAxisMinimum(0);
    }
    private void axisRight(YAxis axis){
        axis.setEnabled(false);
    }
    public void createdCharts(){
        mBarChart =(BarChart)getSameChart(mBarChart,"Series", Color.RED,Color.GREEN,3000);
        mBarChart.setDrawGridBackground(false);
        mBarChart.setDrawBarShadow(false);
        mBarChart.setData(getBarData());
        mBarChart.invalidate();
        axisX(mBarChart.getXAxis());
        axisLeft(mBarChart.getAxisLeft());
        axisRight(mBarChart.getAxisRight());

        mPieChart =(PieChart)getSameChart(mPieChart,"Ventas",Color.GRAY,Color.CYAN,3000);
        mPieChart.setHoleRadius(5);
        mPieChart.setTransparentCircleRadius(6);
        mPieChart.setData(getPieData());
        mPieChart.invalidate();
        //pieChart.setDrawHoleEnabled(false);

    }
    private DataSet getData(DataSet dataSet){
        //dataSet.setColors(mColors);
       // dataSet.setColor(green);
        dataSet.setValueTextSize(Color.WHITE);
        dataSet.setValueTextSize(10);
        return dataSet;
    }
    private BarData getBarData(){
        BarDataSet barDataSet=(BarDataSet)getData(new BarDataSet(getBarEntries(),""));
        barDataSet.setBarShadowColor(Color.GRAY);
        BarData barData=new BarData(barDataSet);
        barData.setBarWidth(0.45f);
        return barData;
    }
    private PieData getPieData(){
        PieDataSet pieDataSet=(PieDataSet)getData(new PieDataSet(getPierEntries(),""));
        pieDataSet.setSliceSpace(2);
        pieDataSet.setValueFormatter(new PercentFormatter());
        return new PieData(pieDataSet);
    }
}